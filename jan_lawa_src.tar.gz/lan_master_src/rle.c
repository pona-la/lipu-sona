// vim: sw=2
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

const char* argv0 = NULL;

int rle(void) {
  size_t in_len = 0;
  bool byteused[256];
  unsigned char bytes[65536];
  int tag_char = -1;

  while (in_len < 65536) {
    int c = getchar();
    if (c == EOF) break;
    byteused[c] = true;
    bytes[in_len] = c;
    in_len++;
  }

  for (int i=0; i<256; i++) 
    if (!byteused[i]) { tag_char = i; break; }

  if (tag_char == -1) {
    fprintf(stderr,"Impossible to pick a tag byte, since source data uses every possible byte at least once.\n");
    return 1;
  }

  int current_byte = -1;
  int run_length = 0;
  size_t in_index = 0;

  putchar(tag_char);

  while (in_index < in_len) {
    int x = bytes[in_index];
    if (current_byte != x) {
      run_length = 0; putchar(x); in_index++; current_byte = x;
    } else {
      in_index++;
      while ((run_length < 254) && ((in_index + run_length) < in_len) && (bytes[in_index + run_length] == current_byte)) run_length++;
      if (run_length > 1) {
      putchar(tag_char); 
      putchar(run_length+1);
      in_index += run_length;
      } else {
      putchar(current_byte);
      }
      run_length = 0;
    }
  }
  putchar(tag_char);
  putchar(0);
  return 0;
}

int unrle(void) {
  int a, byte, tag;
  tag = getchar();

  while (1) {  
    a = getchar();
    if (a == tag) {
      a = getchar();
      if (a == 0) return 0;
      do {putchar(byte); a--;} while(a);
    } else { putchar(a); byte = a; }
  }
}

int errormsg(void) {
  fprintf (stderr,"%s -e -- RLE encode\n",argv0);
  fprintf (stderr,"%s -d -- RLE decode\n",argv0);
  return 1;
}

int main(int argc, char** argv) {

  argv0 = argv[0];
  if (argc != 2) return errormsg();

  if (strcmp(argv[1],"-e") == 0) return rle();
  if (strcmp(argv[1],"-d") == 0) return unrle();
  return errormsg();

}
